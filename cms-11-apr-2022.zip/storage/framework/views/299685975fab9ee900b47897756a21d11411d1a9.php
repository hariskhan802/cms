<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('Admin.Layout.top-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-6 col-lg-6 col-md-6">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <?php echo $__env->make('Admin.Layout.bottom-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Layout/layout-2.blade.php ENDPATH**/ ?>