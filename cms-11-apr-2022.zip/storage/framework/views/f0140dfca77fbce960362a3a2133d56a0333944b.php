



<?php $__env->startSection('content'); ?>

	<div class="main-wrap  <?php echo e($name.'-wrap'); ?>">
            

            
            
            <div class="main-c-wrap profile-wrap">

            
            <?php if(session('errormsg')): ?>
            <div class="card mb-4 border-left-danger">
                <div class="card-body">
                    <?php echo e(session('errormsg')); ?>

                </div>
            </div>
            <?php endif; ?>
            <div class="card shadow mb-4">
                
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__word_format($name, 'ucfirst')); ?></h6>
                </div>
                
                <div class="card-body">
                    <div class="tabs-wrap">
                        <div class="tabs-menu">
                            <ul>
                                <li class="active">
                                    <a href="#information" class="tab">Information</a>
                                </li>
                                <li>
                                    <a href="#change-password"  class="tab">Change Password</a>
                                </li>
                            </ul>
                        </div>
                        <div class="tabs-div">
                            <div class="tab-div" id="information">
                                <form method="post" action="<?php echo e(route('profile')); ?>" enctype="multipart/form-data">
                                    <div class="form-wrap">
                                        <div class="form-head">
                                            <h6>Information</h6>
                                        </div>
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" class="form-control" placeholder="Name" name="name" value="<?php echo e(__c_user()->name); ?>" required>
                                            <small class="error-msg"></small>
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(__c_user()->email); ?>"  required>
                                            <small class="error-msg"></small>
                                        </div>
                                        
                                        <div class="form-group img-f-g">
                                            <label>Image</label>
                                            <input type="file" name="image" accept="image/*" <?php echo e(__c_user()->image == '' ? 'required' : ''); ?> />
                                            <small class="error-msg"></small>
                                            
                                            <img src="<?php echo e(__get_user_image(__c_user()->image)); ?>" width="50">
                                        </div>
                                        <div class="form-group">
                                            <input type="hidden" name="_image" value="<?php echo e(__c_user()->image); ?>">
                                            <input type="hidden" name="_token" value="<?php echo e(@csrf_token()); ?>">
                                            <input type="submit" name="submit" value="Update" class="btn btn-primary pull-right">
                                            
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-div" id="change-password">
                                <form method="post" action="<?php echo e(route('profile')); ?>">
                                    <div class="form-wrap">
                                        <div class="form-head">
                                            <h6>Change Password</h6>
                                        </div>
                                        <div class="form-group">
                                            <label>Current Password</label>
                                            <input type="password" class="form-control" placeholder="Current Password" name="current_password" required>
                                            <small class="error-msg"></small>
                                            <a href="javascript:;" class="p-visibility"><i class="fa fa-eye"></i></a>
                                        </div>
                                        <div class="form-group">
                                            <label>New Password</label>
                                            <input type="password" class="form-control" placeholder="New Password" name="new_password" required>
                                            <small class="error-msg"></small>
                                            <a href="javascript:;" class="p-visibility"><i class="fa fa-eye"></i></a>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation" required>
                                            <small class="error-msg"></small>
                                            <a href="javascript:;" class="p-visibility"><i class="fa fa-eye"></i></a>
                                        </div>
                                        
                                        <div class="form-group">
                                            <input type="hidden" name="_token" value="<?php echo e(@csrf_token()); ?>">
                                            <input type="submit" name="submit" value="Change Password" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="card mb-4 c-msg border-left-success">
                            <div class="card-body"></div>
                        </div>
                    </div>

                    
                    
                </div>
            </div>
                            
            </div>
        </form>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Auth/profile.blade.php ENDPATH**/ ?>