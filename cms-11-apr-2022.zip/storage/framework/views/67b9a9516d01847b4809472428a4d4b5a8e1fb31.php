<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('public/assets/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('public/assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('public/assets/js/sb-admin-2.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="https://cdn.tiny.cloud/1/3nh4mufsrn0nc5aj86g0bvfnwti30qrpaejoitnks3omitzc/tinymce/4/tinymce.min.js" referrerpolicy="origin"></script>
<script src="<?php echo e(asset('public/assets/js/app.js')); ?>"></script><?php /**PATH D:\xampp\htdocs\cms-11-apr-2022\resources\views/Admin/Layout/bottom-scripts.blade.php ENDPATH**/ ?>