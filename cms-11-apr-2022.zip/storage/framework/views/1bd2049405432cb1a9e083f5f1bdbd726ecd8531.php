<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('Admin.Layout.top-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
    localStorage.setItem('app_url', '<?php echo e(url('')); ?>');
    localStorage.setItem('image_extensions', '<?php echo e(__get_image_extensions("string")); ?>');

</script>
<?php echo do_action('wp_head'); ?>

</head>
<?php
    $id = \Request::route('id') ? \Request::route('id') : '0';
    $atts = [
        'page-name' => $name,
        'edit-page-id' => $id,
        'parent-page-name' => __word_format($name, 'plural')
    ];
    
?>
<body id="page-top" class="<?php echo e(__get_admin_body_classes(str_replace(' ','-', $name).'-m-wrap ')); ?>" <?php echo e(__get_admin_body_attributes($atts)); ?>>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('Admin.Layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <?php echo $__env->make('Admin.Layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            
            <?php echo $__env->make('Admin.Layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    

    
    <?php echo $__env->make('Admin.Layout.bottom-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\cms-11-apr-2022\resources\views/Admin/Layout/layout.blade.php ENDPATH**/ ?>