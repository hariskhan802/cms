



<?php $__env->startSection('content'); ?>

	<div class="main-wrap  <?php echo e($name.'-wrap'); ?>">
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms-11-apr-2022\resources\views/Admin/Dashboard/index.blade.php ENDPATH**/ ?>