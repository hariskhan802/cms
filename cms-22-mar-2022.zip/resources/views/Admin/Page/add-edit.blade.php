<div class="modal fade" id="add-edit-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
    <form method="post" action="">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add New</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-wrap">
                    
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Title" name="title" required>
                            <small class="error-msg"></small>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Slug" name="slug" required>
                            <small class="error-msg"></small>
                        </div>
                        <div class="form-group">
                            <select name="template_id"  class="form-control" required>
                                <option value="">Select Template</option>
                                <option value="1">Template 1</option>
                            </select>
                            <small class="error-msg"></small>
                        </div>
                        <div class="form-group">
                            <textarea name="content" class="form-control" id="html-editor" placeholder="Content"></textarea>
                            <small class="error-msg"></small>
                        </div>
                        <div class="form-group">
                            <input type="file" name="featured_image" accept="image/*"  required />
                            <small class="error-msg"></small>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    {{ csrf_field() }}
                    <input type="hidden" name="_post_status">
                    <input type="hidden" name="_featured_image">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <input type="submit" class="btn btn-primary" name="submit" value="Save Draft">
                    <input type="submit" class="btn btn-primary" name="submit" value="Publish">
                </div>
                <div class="card mb-4 c-msg border-left-success">
                    <div class="card-body">
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>