<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\{
    PageController,
    LoginRegistrationController,
};
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function(){
    echo bcrypt('haris');
});



Route::group(['prefix' => 'admin', 'middleware' => ['AdminCheck']], function() {
    Route::match(['get', 'post'], 'login', [LoginRegistrationController::class, 'login'])->name('admin-login');
    Route::get('logout', [LoginRegistrationController::class, 'logout'])->name('admin-logout');

    Route::get('pages', [PageController::class, 'index'])->name('pages');
    // Route::get('pages-ajax', [PageController::class, 'pages_ajax'])->name('pages-ajax');
    Route::post('page/add', [PageController::class, 'add'])->name('add-page');
    Route::match(['get', 'post'], 'page/edit/{id}', [PageController::class, 'edit'])->name('edit-page');
    Route::match(['get', 'post'], 'page/delete/{id?}', [PageController::class, 'delete'])->name('delete-page');
    Route::get('page/restore/{id?}', [PageController::class, 'restore'])->name('restore-page');
    

    Route::get('posts', [PageController::class, 'index'])->name('pages');
    // Route::get('pages-ajax', [PageController::class, 'pages_ajax'])->name('pages-ajax');
    Route::post('post/add', [PageController::class, 'add'])->name('add-page');
    Route::match(['get', 'post'], 'post/edit/{id}', [PageController::class, 'edit'])->name('edit-page');
    Route::match(['get', 'post'], 'post/delete/{id?}', [PageController::class, 'delete'])->name('delete-page');
    Route::get('post/restore/{id?}', [PageController::class, 'restore'])->name('restore-page');

    
});