



<?php $__env->startSection('content'); ?>

	<h2>test 333333333333</h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/test.blade.php ENDPATH**/ ?>