<?php

    function __data_table($data) {
        // $inputs, $table, $columns, $tColumns
        $columnsF = [];
        foreach ($data['columns'] as $key => $column) {
            $columnsF[] = ['data' => stripos($column, 'as') != false ? str_replace(' ', '', substr($column, stripos($column, 'as')+2)) : $column];
        }
        // print_r($columnsF); die;
        $response['frontend'] = "<div class='card shadow mb-4'>
        <div class='card-header py-3'>
            <h6 class='m-0 font-weight-bold text-primary'>".@$data['title']."</h6>
        </div>
        <div class='card-body'><table class='c-datatable table table-bordered' data-columns='".json_encode($columnsF)."' data-url='".route('pages-ajax')."'  >
        <thead>
            <tr>";
        foreach ($data['tColumns'] as $key => $tColumn) {
            if(__is_image($tColumn)) {
                $response['frontend'] .= '<td class="t1"><img src="'.$tColumn.'" width="100" /></td>';
            }
            else {
                $response['frontend'] .= '<td class="t2">'.$tColumn.'</td>';
            }
            
        }
        $response['frontend'] .= ' </tr>
            </thead>
        </table></div>
        </div>';
        if(isset($data['inputs'])){
            $inputs = $data['inputs'];
            
            $columnIndex = $inputs['order'][0]['column'];
            $columnName = $inputs['columns'][$inputs['order'][0]['column']]['data'];
            $columnSortOrder = $inputs['order'][0]['dir'];
            $searchValue = $inputs['search']['value'];

            $totalRecords = $data['table']::select('count(id) as allcount')->count();
            $totalRecordswithFilter = $data['table']::select('count(id) as allcount')->where('title', 'like', '%' .$searchValue . '%')->count();

            $records = $data['table']::orderBy($columnName,$columnSortOrder)
            ->where('pages.title', 'like', '%' .$searchValue . '%')
            ->select($data['columns'])
            ->skip($inputs['start'])
            ->take($inputs['length'])
            ->get()
            ->toArray();
            
        
                
            
            // $columnsF;
            $response['backend'] = array(
                "draw" => intval($inputs['draw']),
                "iTotalRecords" => $totalRecords,
                "iTotalDisplayRecords" => $totalRecordswithFilter,
                "aaData" => $records
            );
        }
        return $response;
    }
    function __is_image($image) {
        $imageExtensions = ['jpg', 'jpeg', 'gif', 'png', 'bmp', 'svg', 'svgz', 'cgm', 'djv', 'djvu', 'ico', 'ief','jpe', 'pbm', 'pgm', 'pnm', 'ppm', 'ras', 'rgb', 'tif', 'tiff', 'wbmp', 'xbm', 'xpm', 'xwd'];

        $explodeImage = explode('.', $image);
        $extension = end($explodeImage);
        // var_dump($extension);
        // var_dump(in_array($extension, $imageExtensions)); 
        return in_array($extension, $imageExtensions);
    }

    function __word_format($name, $type = null) {

        if (!$type) {
           $name = $name;
        }
        else if ($type == 'ucfirst') {
           $name = ucfirst($name);
        }
        else if ($type == 'ucwords') {
           $name = ucwords($name);
        }
        else if ($type == 'plural') {
           $name = \Illuminate\Support\Str::plural($name);
        }
        else if ($type == 'cPlural') {
           $name =  ucfirst(\Illuminate\Support\Str::plural($name));
        }
        return $name;
    }