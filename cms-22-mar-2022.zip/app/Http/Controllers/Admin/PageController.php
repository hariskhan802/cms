<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Page;
use Illuminate\Support\Facades\Validator;
use File;
use Image;

class PageController extends Controller
{
    public function index(Request $req) {

        $page1 = Page::query();
        $page2 = Page::query();
        $name = 'page';
        $totalRecords = $page1->where('post_status', '!=', 'trashed')->where('post_status', '!=', 'deleted')->count();
        if ($req->input('search')) {
            $page2->where('pages.title', 'like', "%{$req->input('search')}%");
        }

        if ($req->input('status') == '') {
            $page2->where(['post_status' => 'published'])->orWhere(['post_status' => 'drafted']);
        }
        else if ($req->input('status') == 'published') {
            $page2->where(['post_status' => 'published']);
        }
        else if ($req->input('status') == 'drafts') {
            $page2->where(['post_status' => 'drafted']);
        }   
        else if ($req->input('status') == 'trash') {
            $page2->where(['post_status' => 'trashed']);
        }
        // $page2 = ;
        return view('Admin.Page.index', ['name' => $name, 'totalRecords' => $totalRecords, 'data' => $page2->select(['pages.id', 'pages.title', 'pages.featured_image', 'templates.title as template', 'pages.updated_at'])->leftjoin('templates', 'templates.id', '=', 'pages.template_id')->orderBy('pages.id', 'DESC')->paginate(10)]);
    }
    public function add(Request $req) {
        $data = $req->all();
        // print_r($data); die;
        $response = ['status' => [], 'errors' => []];
        $validated = Validator::make($data, [
            'title' => 'required',
            'slug' => 'required|unique:pages',
            'template_id' => 'required',
            'content' => 'required',
            'featured_image' => 'required||file|max:100|mimes:jpeg,bmp,png,jpg',
        ]);
        $data['post_status'] = 'drafted';
        if ($data['_post_status'] == 'Publish') {
            $data['post_status'] = 'published';
        }
        if ($validated->fails()) {
            $response['errors'] = $validated->getMessageBag()->toArray();
            $response['status'] = 'fail';
            return $response;
        }
        $image = $req->file('featured_image');
        $input['imagename'] = 'img-'.uniqid().time().'.'.$image->extension();
        $path = public_path('/assets/images');
        if(!File::exists($path)){
            File::makeDirectory($path, $mode = 0777, true, true);
        }
        $img = Image::make($image->path());
        $img->resize(700, 400, function ($constraint) {
            $constraint->aspectRatio();
        })->save($path.'/'.$input['imagename']);
        $data['featured_image'] = $input['imagename'];
        if(Page::create($data)) {
            $response['status'] = 'success';
            $response['message'] = 'You have added successfully';
        }
        return $response;
    }
    public function edit($id, Request $req) {
        if ($req->isMethod('post')) {
            $data = $req->all();
            // print_r($data); die;
            $response = ['status' => [], 'errors' => []];
            $vArgs = [
                'title' => 'required',
                'slug' => 'required|unique:pages',
                'template_id' => 'required',
                'content' => 'required',
                'featured_image' => 'required||file|max:100|mimes:jpeg,bmp,png,jpg',
            ];
            if ($data['_featured_image'] != '')
                unset($vArgs['featured_image']);
            
            if ($data['slug'] == Page::findOrfail($id)->slug)
                unset($vArgs['slug']);

            $validated = Validator::make($data, $vArgs);
            $data['post_status'] = 'drafted';
            if ($data['_post_status'] == 'Publish' || $data['_post_status'] == 'Update') {
                $data['post_status'] = 'published';
            }
            if ($validated->fails()) {
                $response['errors'] = $validated->getMessageBag()->toArray();
                $response['status'] = 'fail';
                return $response;
            }

            $data['featured_image'] = $data['_featured_image'];
            if ($req->file('featured_image')) {
                File::delete('public/assets/images/'.$data['_featured_image']);
                $image = $req->file('featured_image');
                $input['imagename'] = 'img-'.uniqid().time().'.'.$image->extension();
                $path = public_path('/assets/images');
                if(!File::exists($path)){
                    File::makeDirectory($path, $mode = 0777, true, true);
                }
                $img = Image::make($image->path());
                $img->resize(700, 400, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($path.'/'.$input['imagename']);
                $data['featured_image'] = $input['imagename'];
            }

            if(Page::findOrfail($id)->update($data)) {
                $response['status'] = 'success';
                $response['message'] = 'You have updated successfully';
            }
            return $response;
        }
        else {
            $response = ['status' => 'success', 'item' => Page::findOrfail($id)];
            return $response;
        }

    }
    public function delete($id = null, Request $req) {
        if ($id) {
            if (Page::where(['id' => $id])->where('post_status', '!=', 'trashed')->where('post_status', '!=', 'deleted')->count() > 0) {
               Page::where(['id' => $id])->where('post_status', '!=', 'trashed')->where('post_status', '!=', 'deleted')->update(['post_status' => 'trashed']);
            }

            else if (Page::where(['id' => $id, 'post_status' => 'trashed'])->where('post_status', '!=', 'deleted')->count() > 0) {
                Page::where(['id' => $id, 'post_status' => 'trashed'])->where('post_status', '!=', 'deleted')->update(['post_status' => 'deleted']);
            }
            return back()->with('msg', 'Delete successfully');
        }
        else {
            if ($req->input('rec_action') == 'trash') {
                if (Page::whereIn('id', $req->input('action_ids'))->where('post_status', '!=', 'trashed')->where('post_status', '!=', 'deleted')->count() > 0) {
                    Page::whereIn('id', $req->input('action_ids'))->where('post_status', '!=', 'trashed')->where('post_status', '!=', 'deleted')->update(['post_status' => 'trashed']);
                }
            }
            if ($req->input('rec_action') == 'delete') {
                if (Page::whereIn('id', $req->input('action_ids'))->where(['post_status' => 'trashed'])->where('post_status', '!=', 'deleted')->count() > 0) {
                    Page::whereIn('id', $req->input('action_ids'))->where(['post_status' => 'trashed'])->where('post_status', '!=', 'deleted')->update(['post_status' => 'deleted']);
                }
            }
            return back()->with('msg', 'Delete successfully');
        }
    }

    public function restore($id = null, Request $req) {
        if ($id) {
            if (Page::where(['id' => $id, 'post_status' => 'trashed'])->where('post_status', '!=', 'deleted')->count() > 0) {
                Page::where(['id' => $id, 'post_status' => 'trashed'])->where('post_status', '!=', 'deleted')->update(['post_status' => 'published']);
                return back()->with('msg', 'Restored successfully');
            }
        }
        else {
            if ($req->input('rec_action') == 'restore') {
                if (Page::whereIn('id', $req->input('action_ids'))->where('post_status', 'trashed')->where('post_status', '!=', 'deleted')->count() > 0) {

                    Page::whereIn('id', $req->input('action_ids'))->where('post_status', 'trashed')->where('post_status', '!=', 'deleted')->update(['post_status' => 'published']);
                    return back()->with('msg', 'Restored successfully');
                }
            }
        }
    }
    public function pages_ajax(Request $req) {
        
        // return __data_table($req->all(), Page::class, ['id', 'title', 'template_id AS template', 'featured_image', 'updated_at AS date'], )['backend'];
    
        return __data_table(['inputs' => $req->all(), 'table' => Page::class, 'columns' => ['id', 'title', 'template_id AS template', 'featured_image', 'updated_at AS date'], 'tColumns' => ['ID', 'Title', 'Template', 'Featured Image', 'Date']])['backend'];
    }

    
}
