<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LoginRegistrationController extends Controller
{
    //
    public function login(Request $req) {
        if ($req->isMethod('post')) {
            $data = $req->all();
            $validated = \Validator::make($data, [
                'email' => 'required',
                'password' => 'required',
            ]);
            if ($validated->fails()) {
                return back()->withErrors($validated)->withInput();
            }
            $userInfo = \App\Models\User::where(['email' => $data['email']])->first();

            // dd($userInfo);
            if ($userInfo) {
                if (\Hash::check($data['password'], $userInfo->password)) {
                    session()->put(['admin_user_id' => $userInfo->id, 'admin_name' => $userInfo->name, 'admin_email' => $userInfo->email]);
                    // print_r($request->query('redirect')); die;
                    if ($req->query('redirect')){

                        return redirect($request->query('redirect'));
                    }
                    return redirect(route('pages'));
                }
                else{
                    return back()->with('errormsg', 'Email or password is incorrect!');

                }
            }
            else{
                return back()->with('errormsg', 'Email or password is incorrect!');
            }

        }
        else {
            return view('Admin.Login-Registration-ForgotPassword.login');
        }
    }

    public function logout(Request $req) {
        if (session()->has('admin_user_id')) {
            session()->pull('admin_user_id');
            session()->pull('admin_name');
            session()->pull('admin_email');
            return redirect(route('admin-login'));
        }
    }
}
