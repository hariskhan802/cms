<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        DB::table('users')->insert([
                'name' => 'haris',
                'email' => 'haris@gmail.com',
                'password' => bcrypt('haris'),
                'email_verified_at' => now(),
                
            ]);
        DB::table('templates')->insert([
                'title' => 'Template 1',
                'content' => 'Template 1',
                'created_at' => now(),
                'updated_at' => now(),
                
            ]);
    }
}
