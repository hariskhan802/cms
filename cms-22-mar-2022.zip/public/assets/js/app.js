    
    $(document).ready(function(){

        function __ajax($this, data = null, type = 'post', URL = null){
            var formData;
            if ($this)
                formData = new FormData($this);

            for(dd in data) {
                for(d in Object.keys(data[dd])) {
                    formData.append(Object.keys(data[dd])[d], Object.values(data[dd])[d]);
                }
            }
            var URL = URL ? URL : $($this).attr('action');
            console.log(URL);
            return $.ajax({
                        url: URL,
                        type: type,
                        data: formData,
                        contentType: false,
                        processData: false,
                        cache: false,
                        error: function() {
                            alert('Something went wrong!');
                            $('[name="submit"]').prop('disabled', false);
                        }
                    });
        }
        function isHTML(str) {
            var a = document.createElement('div');
            a.innerHTML = str;

            for (var c = a.childNodes, i = c.length; i--; ) {
                if (c[i].nodeType == 1) return true; 
            }

            return false;
        }

        function __is_image($image = '') {
            $image = $image+'';
            $imageExtensions = ['jpg', 'jpeg', 'gif', 'png', 'bmp', 'svg', 'svgz', 'cgm', 'djv', 'djvu', 'ico', 'ief','jpe', 'pbm', 'pgm', 'pnm', 'ppm', 'ras', 'rgb', 'tif', 'tiff', 'wbmp', 'xbm', 'xpm', 'xwd'];
            $explodeImage = $image.split('.');
            $extension = $explodeImage[($explodeImage.length-1)];
            // console.log();
            return $imageExtensions.indexOf($extension) != -1;
        }
        // console.log(__is_image('img-6238bdf2d73401647885810zjpg'));
        /* $('.c-datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: $('.c-datatable').attr('data-url'),
            columns: [
            { data: 'id' },
            { data: 'title' },
            { data: 'template' },
            { data: 'featured_image' },
            { data: 'date' },
            ],
            columnDefs: [ {
                "targets": 3,
                "data": "download_link",
                "render": function ( data, type, row, meta ) {
                  return '<img src="'+data+'">';
                }
              } ]
        }); */
        $('.c-datatable').DataTable();
        if (typeof tinymce != "undefined") {
            tinymce.init({
                selector: '#html-editor',

                height: 500,
                toolbar1: "undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image code | mybutton",
                toolbar2: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | visualchars visualblocks nonbreaking pagebreak restoredraft",
                menubar: false,
                plugins: [
                    "advlist autolink link image lists charmap print preview hr anchor pagebreak",
                    "searchreplace wordcount visualblocks visualchars insertdatetime media nonbreaking",
                    "table contextmenu directionality emoticons paste textcolor code"
                ],
                content_css: [
                    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                    // '//www.tinymce.com/css/codepen.min.css'
                    ],
            });
        }

        $('#add-edit-modal form').submit(function(e) {
            e.preventDefault();
            $('[name="submit"]').prop('disabled', true);
            $('.error-msg').empty();
            __ajax(this).then(function(data) {
                if('errors' in data && data.status == 'fail') {
                    $.each(data.errors,function(k, v) {
                        $('[name="'+k+'"]').next('.error-msg').html(v);
                    });
                    $('[name="submit"]').prop('disabled', false);
                }
                else if (data.status == 'success') {
                    $('.card.mb-4.c-msg.border-left-success').html(data.message).show('slow').delay(3000).hide('slow');
                    setTimeout(function(){
                        $('#add-edit-modal').modal('toggle');
                        location.reload();
                    }, 2000);
                }
                
            });
        });
        $('.f-action-switcher').click(function() {
            $('#add-edit-modal form').attr('action', $(this).attr('data-form'));
        });
        $('[name="submit"][value="Publish"]').click(function() {
            if ($('#add-edit-modal form')[0].checkValidity()) {
                console.log($(this).val())
                $('[name="_post_status"]').val($(this).val())
            }
            
        });
        $('.danger-delete').click(function(e) {
            e.preventDefault();
            $('#delete-modal').modal('toggle');
            $('.confirm-btn').attr('href', $(this).attr('href'));
        });

        console.log($('.c-table thead th').length);
        $('.nofound-td').attr('colspan', $('.c-table thead th').length);
        
        $('.edit-record').click(function(e) {
            e.preventDefault();
            $('[type="submit"][value="Save Draft"]').hide();
            $('#add-edit-modal form').attr('action', $(this).attr('href'))
            $('#add-edit-modal').modal('toggle');
            __ajax(null, null, 'get', $(this).attr('href')).then(function(data) {
                /*if('errors' in data && data.status == 'fail') {
                    $.each(data.errors,function(k, v) {
                        $('[name="'+k+'"]').next('.error-msg').html(v);
                    });
                    $('[name="submit"]').prop('disabled', false);
                }
                else */
                if (data.status == 'success') {
                    var post_status = '';
                    if (data.item.post_status == 'drafted') {
                        post_status = 'Publish';
                    }
                    else {
                        post_status = 'Update';
                    }
                    $('[type="submit"][value="Publish"]').val(post_status);
                    console.log(post_status);
                    $('[name="_post_status"]').val(post_status);
                    $.each(data.item,function(k, v) {
                        if (__is_image(v)) {

                            var app_url = localStorage.getItem('app_url');
                            $('[name="'+k+'"]').removeAttr('required');
                            $('[name="_'+k+'"]').val(v)
                            $('[name="'+k+'"]').after('<img src="'+app_url+'/public/assets/images/'+v+'" width="100" />');
                        }

                        isHTML(v) ? tinymce.activeEditor.setContent("<p>Hello world!</p>") : $('[name="'+k+'"]').val(v);
                    });
                    
                }
                
            });
        });
        
        $('.all-checked').click(function() {
            if ($(this).is(':checked')) {
                $('[name="action_ids[]"]').prop('checked', true);
            }
            else {
                $('[name="action_ids[]"]').prop('checked', false);
            }
        });

        $('[name="rec_action"]').change(function(e) {
            var ids = [];
            $('[name="action_ids[]"]:checked').each(function() {
                ids.push(this.value)
            });
            if (ids.length == 0) {
                alert('You must select any record before doing this action!');
                $(this).val('');
                return false;
            }
            $(this).closest('form').attr('action', $(this).find('option:selected').attr('data-form'));
            $(this).closest('form').trigger('submit');
        });
    });