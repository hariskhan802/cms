



<?php $__env->startSection('content'); ?>
    
	<div class="main-wrap  <?php echo e($postType.'-wrap'); ?>">
        <form>
            <input type="hidden" name="post_type" value="<?php echo e($postType); ?>">
            <?php if(session('msg')): ?>
            <div class="card mb-4 border-left-success">
                <div class="card-body">
                    <?php echo e(session('msg')); ?>

                </div>
            </div>
            <?php endif; ?>

            <?php if(session('errormsg')): ?>
            <div class="card mb-4 border-left-danger">
                <div class="card-body">
                    <?php echo e(session('errormsg')); ?>

                </div>
            </div>
            <?php endif; ?>
            <div class="btn-wrap">
                <a  href="<?php echo e(get_admin_post_type_url(['name' => 'add-post'], $postType)); ?>" class="btn btn-primary btn-icon-split  f-action-switcher add-new-record ">
                    <span class="icon text-white-50">
                        <i class="fas fa-plus"></i>
                    </span>
                    <span class="text">Add New</span>
                </a>
            </div>
            <div class="table-wrap">
            <div class="card shadow mb-4">

                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e($currentPostType['name']); ?></h6>
                </div>
                
                <div class="row c-row">

                    <div class="column c-column">

                        <div class="records-status-wrap">
                            <ul>
                                <li class=" <?php echo e(\Request::input('status') == '' ? 'active' : ''); ?> "><a href="<?php echo e(get_admin_post_type_url(['name' => 'posts'], $postType)); ?>">All</a></li>
                                <li class=" <?php echo e(\Request::input('status') == 'published' ? 'active' : ''); ?> "><a href="<?php echo e(get_admin_post_type_url(['name' => 'posts'], $postType).'&status=published'); ?>">Published</a></li>
                                <li class=" <?php echo e(\Request::input('status') == 'drafts' ? 'active' : ''); ?> "><a href="<?php echo e(get_admin_post_type_url(['name' => 'posts'], $postType).'&status=drafts'); ?>">Drafts</a></li>
                                <li class=" <?php echo e(\Request::input('status') == 'trash' ? 'active' : ''); ?> "><a href="<?php echo e(get_admin_post_type_url(['name' => 'posts'], $postType).'&status=trash'); ?>">Trash</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="column c-column">

                        <div class="search-wrap ">
                            <select class="rec-action" name="rec_action">
                                <option value="">-----------</option>
                                <?php if(\Request::input('status') != 'trash'): ?>
                                <option value="trash" data-form="<?php echo e(get_admin_post_type_url(['name' => 'delete-post'], $postType)); ?>">Trash</option>
                                <?php elseif(\Request::input('status') == 'trash'): ?>
                                <option value="delete" data-form="<?php echo e(get_admin_post_type_url(['name' => 'delete-post'], $postType)); ?>">Delete</option>
                                <option value="restore" data-form="<?php echo e(get_admin_post_type_url(['name' => 'restore-post'], $postType)); ?>">Restore</option>
                                <?php endif; ?>
                            </select>
                            
                        </div>
                    </div>
                     <div class="column c-column">

                        <div class="search-wrap ">
                            
                            <input type="text" name="search" placeholder="Search" value="<?php echo e(\Request::input('search')); ?>" class="pull-right">
                            
                        </div>
                    </div>
                </div>
                <div class="row c-row">
                    <div class="column c-column">
                        <div class="total-record">
                            <span>Total Records : <?php echo e($totalRecords); ?></span>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered c-table"  width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th><input type="checkbox"  class="all-checked"></th>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Slug</th>
                                    <?php if($postType != 'page'): ?>
                                    <th>Category</th>
                                    <?php endif; ?>
                                    <th>Featured Image</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($data->count() > 0): ?>
                                    
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" name="action_ids[]" value="<?php echo e($record->id); ?>"></td>
                                            <td><?php echo e($record->id); ?></td>
                                            <td><?php echo e($record->title); ?></td>
                                            <td><?php echo e($record->slug); ?></td>
                                            <?php if($postType != 'page'): ?>
                                            <td><p><?php echo implode("<br> ", __get_category_string_format($record->id)); ?></p></td>
                                            <?php endif; ?>
                                            <td><img src="<?php echo e(__get_image($record->featured_image)); ?>" width="50"></td>
                                            <td><?php echo get_admin_panel_dates($record); ?></td>
                                            <td class="action">
                                                <?php if(\Request::input('status') != 'trash'): ?>
                                                <a href="<?php echo e(get_admin_post_type_url(['name' => 'edit-post', 'id' => $record->id], $postType)); ?>" class="edit-record"><i class="fa fa-pencil-alt"></i></a>
                                                <?php else: ?>
                                                <a href="<?php echo e(get_admin_post_type_url(['name' => 'restore-post', 'id' => $record->id], $postType)); ?>">
                                                    <i class="fa fa-undo"></i>
                                                </a>
                                                <?php endif; ?>
                                                <a href="<?php echo e(get_admin_post_type_url(['name' => 'delete-post', 'id' => $record->id], $postType)); ?>" class="<?php echo e(\Request::input('status') == 'trash' ? 'danger-delete' : ''); ?>">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td class="nofound-td">There is not record</td>
                                        
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="pagination">
                    <?php echo e($data->appends(\Request::query())->links()); ?>

                    </div>
                </div>
            </div>
                            
            </div>
        </form>
    </div>

    <div class="modal fade" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Are you sure?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Confirm" below if you want to delete.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary confirm-btn" href="" >Confirm</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Post/index.blade.php ENDPATH**/ ?>