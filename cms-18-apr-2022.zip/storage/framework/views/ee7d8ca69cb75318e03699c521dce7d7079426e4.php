



<?php $__env->startSection('content'); ?>

	<div class="main-wrap <?php echo e($name.'-wrap'); ?>">
        <form>
            <?php if(session('msg')): ?>
            <div class="card mb-4 border-left-success">
                <div class="card-body">
                    <?php echo e(session('msg')); ?>

                </div>
            </div>
            <?php endif; ?>

            <?php if(session('errormsg')): ?>
            <div class="card mb-4 border-left-danger">
                <div class="card-body">
                    <?php echo e(session('errormsg')); ?>

                </div>
            </div>
            <?php endif; ?>
            <div class="btn-wrap">
                <a data-toggle="modal" data-target="#add-edit-modal" data-form="<?php echo e(route('add-'.__word_format($name))); ?>" class="btn btn-primary btn-icon-split  f-action-switcher add-new-record ">
                    <span class="icon text-white-50">
                        <i class="fas fa-plus"></i>
                    </span>
                    <span class="text">Add New</span>
                </a>
            </div>
            <div class="table-wrap">
            <div class="card shadow mb-4">

                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(__word_format($name, 'cPlural')); ?></h6>
                </div>
                
                <div class="row c-row">

                    <div class="column c-column">

                        
                    </div>
                    <div class="column c-column">

                        <div class="search-wrap ">
                            <select class="rec-action" name="rec_action">
                                <option value="">-----------</option>
                                <option value="delete" data-form="<?php echo e(route('delete-'.__word_format($name))); ?>">Delete</option>
                            </select>
                            
                        </div>
                    </div>
                     <div class="column c-column">

                        <div class="search-wrap ">
                            
                            <input type="text" name="search" placeholder="Search" value="<?php echo e(\Request::input('search')); ?>" class="pull-right">
                            
                        </div>
                    </div>
                </div>
                
                <div class="row c-row">
                    <div class="column c-column">
                        <div class="total-record">
                            <span>Total Records : <?php echo e($totalRecords); ?></span>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered c-table"  width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th><input type="checkbox"  class="all-checked"></th>
                                    <th>ID</th>
                                    <th>Role</th>
                                    <th>Permissions</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($data->count() > 0): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" name="action_ids[]" value="<?php echo e($record->id); ?>"></td>
                                            <td><?php echo e($record->id); ?></td>
                                            <td><?php echo e($record->role); ?></td>
                                            <td>
                                                <?php
                                                    $permissions = json_decode($record->permissions) == '' ? [] : json_decode($record->permissions);
                                                ?>
                                                <?php if(count($permissions) > 0): ?>
                                                    <ul class="perm-list p-l-hide">
                                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e(ucwords(str_replace('_', ' ', $permission))); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                    <?php if(count(json_decode($record->permissions)) > 3): ?>
                                                        <a href="javascript:;" class="s-m-perm">Show More</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                            </td>
                                            <td><?php echo get_admin_panel_dates($record); ?></td>
                                            <td class="action">
                                                <?php if($record->id != 1 && $record->id != 2): ?>
                                                
                                                <a href="<?php echo e(route('edit-'.__word_format($name), $record->id)); ?>" class="edit-record"><i class="fa fa-pencil-alt"></i></a>
                                                <a href="<?php echo e(route('delete-'.__word_format($name), $record->id)); ?>" class="danger-delete">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                                <?php else: ?>
                                                <a href="javascript:;">-</a>
                                                <a href="javascript:;">-</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td class="nofound-td">There is not record</td>
                                        
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="pagination">
                    <?php echo e($data->appends(\Request::query())->links()); ?>

                    </div>
                </div>
            </div>
                            
            </div>
        </form>
    </div>

    <div class="modal fade" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Are you sure?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Confirm" below if you want to delete.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary confirm-btn" href="" >Confirm</a>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('Admin.'.__word_format($name, 'ucfirst').'.add-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Role/index.blade.php ENDPATH**/ ?>