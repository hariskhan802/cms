		<!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Ziltex CMS</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('dashboard') ? 'active' : ''); ?> " href="<?php echo e(route('dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">
            <?php if(count(get_post_types()) > 0): ?>
                <?php $__currentLoopData = get_post_types_object(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item <?php echo e(( (Route::is('posts') || Route::is('add-post')  || Route::is('edit-post')) && \Request::get('post_type') == $postType['post_type'] ) ? 'active' : ''); ?>">
                        <a class="nav-link " href="<?php echo e(route('posts').'?post_type='.$postType['post_type']); ?>" >
                            <i class="fas fa-fw fa-folder"></i>
                            <span><?php echo e($postType['name']); ?></span>
                        </a>
                        <div id="collapsePosts" class="cus-sub-menu collapse  <?php echo e(( (Route::is('posts') || Route::is('add-post')  || Route::is('edit-post')) && \Request::get('post_type') == $postType['post_type'] ) ? 'show' : ''); ?> " aria-labelledby="headingPages"
                            data-parent="#accordionSidebar">
                            <ul>
                                <li class="<?php echo e((Route::is('posts') && \Request::get('post_type') == $postType['post_type'] ) ? 'active' : ''); ?>">
                                    <a href="<?php echo e(get_admin_post_type_url(['name' => 'posts'], $postType['post_type'])); ?>">View</a>
                                </li>
                                <li class="<?php echo e((Route::is('add-post') && \Request::get('post_type') == $postType['post_type'] ) ? 'active' : ''); ?>">
                                    <a href="<?php echo e(get_admin_post_type_url(['name' => 'add-post'], $postType['post_type'])); ?>">Add New</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- <li class="nav-item <?php echo e((Route::is('posts') || Route::is('categories')) ? 'active' : ''); ?>">
                <a class="nav-link " href="<?php echo e(route('posts')); ?>" >
                    <i class="fas fa-fw fa-folder"></i>
                    <span>Posts</span>
                </a>
                <div id="collapsePosts" class="collapse <?php echo e((Route::is('posts') || Route::is('categories')) ? 'show' : ''); ?>" aria-labelledby="headingPages"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?php echo e(Route::is('categories') ? 'active' : ''); ?>" href="<?php echo e(route('categories')); ?>">Categories</a>
                        
                    </div>
                </div>
            </li> 
            <li class="nav-item <?php echo e(Route::is('pages') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('pages')); ?>">
                    <i class="fas fa-fw fa-copy"></i>
                    <span>Pages</span></a>
            </li> -->

            <li class="nav-item <?php echo e(Route::is('templates') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('templates')); ?>">
                    <i class="fas fa-fw fa-copy"></i>
                    <span>Templates</span></a>
            </li>

            <li class="nav-item <?php echo e(Route::is('comments') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('comments')); ?>">
                    <i class="fas fa-fw fa-comment"></i>
                    <span>Comments</span></a>
            </li>
            <li class="nav-item <?php echo e(Route::is('users') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('users')); ?>">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Users</span></a>
            </li>
            <li class="nav-item <?php echo e(Route::is('roles') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('roles')); ?>">
                    <i class="fas fa-fw fa-copy"></i>
                    <span>Roles</span></a>
            </li>
            <li class="nav-item <?php echo e(Route::is('profile') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('profile')); ?>">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Profile</span></a>
            </li>
            

            

            <li class="nav-item <?php echo e(Route::is('general-settings') ? 'active' : ''); ?>">
                <a class="nav-link " href="<?php echo e(route('general-settings')); ?>" >
                    <i class="fas fa-fw fa-cogs"></i>
                    <span>Settings</span>
                </a>
                <div id="collapsePosts" class="collapse <?php echo e((Route::is('general-settings') || Route::is('roles-settings')) ? 'show' : ''); ?>" aria-labelledby="headingPages"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item <?php echo e(Route::is('general-settings') ? 'active' : ''); ?>" href="<?php echo e(route('general-settings')); ?>">General Settings</a>
                        <a class="collapse-item <?php echo e(Route::is('roles-settings') ? 'active' : ''); ?>" href="<?php echo e(route('roles-settings')); ?>">Roles Settings</a>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar --><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Layout/sidebar.blade.php ENDPATH**/ ?>