



<?php $__env->startSection('content'); ?>

	<div class="main-wrap  <?php echo e($name.'-wrap'); ?>">
        <?php if(session('msg')): ?>
        <div class="card mb-4 border-left-success">
            <div class="card-body">
                <?php echo e(session('msg')); ?>

            </div>
        </div>
        <?php endif; ?>

        <?php if(session('errormsg')): ?>
        <div class="card mb-4 border-left-danger">
            <div class="card-body">
                <?php echo e(session('errormsg')); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Dashboard/index.blade.php ENDPATH**/ ?>