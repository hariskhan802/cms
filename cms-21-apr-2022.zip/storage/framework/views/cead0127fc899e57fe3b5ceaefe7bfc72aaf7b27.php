<!DOCTYPE html>
<html lang="en">

<head>
<?php echo $__env->make('Admin.Layout.top-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
    $postType = (isset($postType) && !empty($postType)) ? $postType : '';
?>
<script type="text/javascript">
    localStorage.setItem('app_url', '<?php echo e(url('')); ?>');
    localStorage.setItem('image_extensions', '<?php echo e(get_image_extensions("string")); ?>');
    var postType = '<?php echo e($postType); ?>';
</script>
<?php echo do_action('wp_head'); ?>

</head>
<?php

    $id = \Request::route('id') ? \Request::route('id') : '0';
    
    if($postType != '') {
        $name = $postType;
        $postType = 'post-type';
    }
    $atts = [
        'page-name' => $name,
        'edit-page-id' => $id,
        'parent-page-name' => word_format($name, 'plural')
    ];
    if (Route::is('edit-*')  ) {
        $atts['edit-page-url'] = route(\Request::route()->getName(), \Request::route()->parameter('id'));
    }
?>
<body id="page-top" class="<?php echo e(get_admin_body_classes(str_replace(' ','-', $name).'-m-wrap '.$postType)); ?>" <?php echo e(get_admin_body_attributes($atts)); ?>>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('Admin.Layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <?php echo $__env->make('Admin.Layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            
            <?php echo $__env->make('Admin.Layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    

    
    <?php echo $__env->make('Admin.Layout.bottom-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Layout/layout.blade.php ENDPATH**/ ?>