



<?php $__env->startSection('content'); ?>

	<div class="main-wrap <?php echo e($name.'-wrap'); ?>">
            
            <div class="main-c-wrap roles-settings-wrap">

            <?php if(session('errormsg')): ?>
            <div class="card mb-4 border-left-danger">
                <div class="card-body">
                    <?php echo e(session('errormsg')); ?>

                </div>
            </div>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('roles-settings')); ?>" enctype="multipart/form-data">
            <div class="card shadow mb-4">
                
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e(word_format($name, 'ucfirst')); ?></h6>
                </div>
                
                <div class="card-body">
                    <div class="tabs-wrap">
                        <div class="tabs-menu">
                            <ul>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e($key1 == 0 ? 'active' : ''); ?>">
                                    <a href="#<?php echo e(strtolower($role->role)); ?>" class="tab"><?php echo e($role->role); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="tabs-div">

                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-div" id="<?php echo e(strtolower($role->role)); ?>">
                                <div class="form-wrap">
                                    <div class="form-head">
                                        <h6><?php echo e($role->role); ?></h6>
                                        <input type="checkbox" class="checked-roles">
                                    </div>
                                    <?php $__currentLoopData = get_roles_permissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $role_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                    $permissions = json_decode($role->permissions) ? json_decode($role->permissions) : [];
                                    ?>
                                    <div class="form-group-wrap">
                                        <div class="form-c-wrap">
                                            <label class="m-label"><?php echo e(ucfirst($key2)); ?></label>
                                            <input type="checkbox" class="checked-roles">
                                            <?php $__currentLoopData = $role_p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key3 => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php // var_dump($r) ?>
                                            
                                            <div class="form-group checkbox-fg">
                                                <input type="checkbox" class="form-control"  name="<?php echo e('roles['.strtolower($role->role).']['.$r.']'); ?>" id="<?php echo e('roles['.strtolower($role->role).']['.$r.']'); ?>"  <?php echo e((in_array($r, $permissions) ? 'checked=checked' : '')); ?>>
                                                <label for="<?php echo e('roles['.strtolower($role->role).']['.$r.']'); ?>" class="c-label"><?php echo e(ucwords(str_replace('_', ' ', $r))); ?></label>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group">
                                        <input type="hidden" name="_token" value="<?php echo e(@csrf_token()); ?>">
                                        <input type="submit" name="submit" value="Update" class="btn btn-primary pull-right">
                                        
                                    </div>
                                </div>
                                
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-div" id="subscriber">
                                
                            </div>
                        </div>
                        <div class="card mb-4 c-msg border-left-success">
                            <div class="card-body"></div>
                        </div>
                    </div>

                    
                    
                </div>
            </div>
            </form>          
            </div>
        </form>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms\resources\views/Admin/Settings/roles-settings.blade.php ENDPATH**/ ?>